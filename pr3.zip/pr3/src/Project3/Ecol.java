package Project3;

public enum Ecol { Full, Empty
}
